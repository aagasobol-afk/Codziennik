CODZIENNIK — wersja 1.0

Pierwsza wersja natywnej aplikacji Android.

Funkcje:
- 6 codziennych pól do odhaczenia
- zapis zaznaczeń dla każdego dnia
- licznik postępu 0/6
- komunikat po wykonaniu wszystkich 6 zadań
- notatka dnia zapisywana lokalnie

Uruchomienie:
1. Zainstaluj Android Studio.
2. Otwórz folder Codziennik jako projekt.
3. Poczekaj na synchronizację Gradle.
4. Podłącz telefon z włączonym debugowaniem USB albo uruchom emulator.
5. Kliknij Run.

Projekt jest przygotowany pod Android Studio i Kotlin.
