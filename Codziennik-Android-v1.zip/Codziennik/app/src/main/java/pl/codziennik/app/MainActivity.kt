package pl.codziennik.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.content.Context
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("codziennik", Context.MODE_PRIVATE) }
    private val tasks = listOf(
        "🚫  Dzień bez nałogów",
        "🏃  30 min ćwiczeń siłowych",
        "🌿  Coś dla ogrodu",
        "📸  Fotografia",
        "🏔️  Góry / spacer",
        "✅  Własne zadanie dnia"
    )
    private val dateKey get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 20); setBackgroundColor(Color.rgb(247,244,238)) }
        val title = TextView(this).apply { text = "📖  CODZIENNIK"; textSize = 28f; setTextColor(Color.rgb(47,48,44)); typeface = Typeface.DEFAULT_BOLD }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val date = TextView(this).apply { text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("pl","PL")).format(Date()).replaceFirstChar { it.uppercase() }; textSize=16f; setTextColor(Color.DKGRAY); setPadding(0,6,0,20) }
        root.addView(date)

        val progress = TextView(this).apply { textSize=18f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(102,122,91)); setPadding(0,0,0,10) }
        root.addView(progress)

        val checks = mutableListOf<CheckBox>()
        tasks.forEachIndexed { i, task ->
            val cb = CheckBox(this).apply { text=task; textSize=17f; setTextColor(Color.rgb(47,48,44)); buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(102,122,91)); isChecked=prefs.getBoolean("$dateKey-$i", false); setPadding(0,8,0,8) }
            cb.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("$dateKey-$i", checked).apply(); updateProgress(progress, checks) }
            checks.add(cb); root.addView(cb, LinearLayout.LayoutParams(-1, -2))
        }
        val noteLabel = TextView(this).apply { text="Notatka dnia"; textSize=18f; typeface=Typeface.DEFAULT_BOLD; setPadding(0,18,0,6) }
        root.addView(noteLabel)
        val note = EditText(this).apply { hint="Co dziś zapamiętać?"; setText(prefs.getString("$dateKey-note", "")); minLines=3; gravity=Gravity.TOP; setBackgroundColor(Color.WHITE); setPadding(14,12,14,12) }
        root.addView(note, LinearLayout.LayoutParams(-1, 110))
        val save = Button(this).apply { text="Zapisz notatkę"; setOnClickListener { prefs.edit().putString("$dateKey-note", note.text.toString()).apply(); Toast.makeText(this@MainActivity,"Zapisane ✓",Toast.LENGTH_SHORT).show() } }
        root.addView(save)
        updateProgress(progress, checks)
        setContentView(root)
    }

    private fun updateProgress(v: TextView, checks: List<CheckBox>) {
        val n=checks.count{it.isChecked}; v.text=if(n==6) "🎉  DZIEŃ ZROBIONY ✓" else "Postęp dnia: $n / 6"
    }
}
