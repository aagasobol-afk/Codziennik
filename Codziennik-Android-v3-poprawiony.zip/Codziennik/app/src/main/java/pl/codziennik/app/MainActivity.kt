package pl.codziennik.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("codziennik", MODE_PRIVATE) }
    private val allTasks = listOf(
        "🚫  Dzień bez nałogów", "🏃  30 min ćwiczeń siłowych", "🌿  Coś dla ogrodu",
        "📸  Fotografia", "🚶  Spacer", "💊  Suplementacja", "✅  Własne zadanie dnia"
    )
    private val backgrounds = listOf(
        "Jezioro • mgła" to R.drawable.bg_lake,
        "Las • głęboka zieleń" to R.drawable.bg_forest,
        "Góry • poranna mgła" to R.drawable.bg_mountains,
        "Trawy • beż i piasek" to R.drawable.bg_grass,
        "Łąka • rudy i oliwka" to R.drawable.bg_meadow
    )
    private val dateKey: String get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private val plDate: String get() = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("pl","PL")).format(Date()).replaceFirstChar { it.uppercase() }
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var progress: TextView
    private var memoryImage: ImageView? = null
    private val photoRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun card(bg: Int, radius: Float = 20f): GradientDrawable = GradientDrawable().apply { setColor(bg); cornerRadius = dp(radius.toInt()).toFloat() }

    private fun buildUi() {
        root = FrameLayout(this)
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageResource(backgrounds[prefs.getInt("background",0)].second) }
        root.addView(bg, FrameLayout.LayoutParams(-1,-1))
        val shade = View(this).apply { setBackgroundColor(Color.argb(75,0,0,0)) }
        root.addView(shade, FrameLayout.LayoutParams(-1,-1))

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(12),dp(16),dp(18)); overScrollMode=View.OVER_SCROLL_NEVER }
        val scroll = ScrollView(this).apply { clipToPadding=false; addView(content) }
        root.addView(scroll, FrameLayout.LayoutParams(-1,-1))
        setContentView(root)

        val top = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val menu = Button(this).apply { text="☰"; textSize=22f; setTextColor(Color.WHITE); setBackgroundColor(0); setOnClickListener { showMenu() } }
        top.addView(menu, LinearLayout.LayoutParams(dp(48),dp(48)))
        val titleBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER }
        titleBox.addView(TextView(this).apply { text="Codziennik"; textSize=28f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; typeface=android.graphics.Typeface.create("serif",0) })
        titleBox.addView(TextView(this).apply { text="Małe kroki, wielkie zmiany"; textSize=11f; letterSpacing=.22f; setTextColor(Color.WHITE); gravity=Gravity.CENTER })
        top.addView(titleBox, LinearLayout.LayoutParams(0,-2,1f))
        val search = Button(this).apply { text="⌕"; textSize=28f; setTextColor(Color.WHITE); setBackgroundColor(0); setOnClickListener { Toast.makeText(this@MainActivity,"Wyszukiwanie dodamy w kolejnej wersji 🙂",Toast.LENGTH_SHORT).show() } }
        top.addView(search, LinearLayout.LayoutParams(dp(48),dp(48)))
        content.addView(top)

        content.addView(TextView(this).apply { text=plDate; textSize=18f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,dp(5),0,dp(6)) })
        progress = TextView(this).apply { textSize=18f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setTypeface(null,android.graphics.Typeface.BOLD); setPadding(0,0,0,dp(10)) }
        content.addView(progress)

        val tileWrap = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val selected = selectedIndices()
        val checks = mutableListOf<CheckBox>()
        selected.forEachIndexed { pos, index ->
            val cb = CheckBox(this).apply {
                text=allTasks[index]; textSize=16f; setTextColor(Color.rgb(45,48,44)); buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(104,116,90));
                setPadding(dp(8),dp(5),dp(8),dp(5)); background=card(Color.argb(235,242,235,221),18f); isChecked=prefs.getBoolean("$dateKey-$index",false)
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("$dateKey-$index",checked).apply(); paintFlags=if(checked) paintFlags or Paint.STRIKE_THRU_TEXT_FLAG else paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv(); updateProgress(checks, selected.size) }
                if(isChecked) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            }
            checks.add(cb); tileWrap.addView(cb, LinearLayout.LayoutParams(-1,dp(56)).apply{bottomMargin=dp(7)})
        }
        content.addView(tileWrap)

        val memoryCard = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(14)); background=card(Color.argb(242,242,235,221),22f) }
        val memHead = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        memHead.addView(TextView(this).apply { text="Pamiątka z dnia"; textSize=20f; setTextColor(Color.rgb(45,48,44)); typeface=android.graphics.Typeface.create("serif",android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0,-2,1f))
        memHead.addView(TextView(this).apply { text="⋮"; textSize=24f; setTextColor(Color.rgb(45,48,44)); setOnClickListener{choosePhoto()} }, LinearLayout.LayoutParams(dp(40),dp(40)))
        memoryCard.addView(memHead)
        val photo = ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; background=card(Color.rgb(225,219,208),18f); setPadding(0,0,0,0) }
        memoryImage=photo
        val uri=prefs.getString("$dateKey-photo",null)
        if(uri!=null) try{photo.setImageURI(Uri.parse(uri))}catch(_:Exception){}
        memoryCard.addView(photo, LinearLayout.LayoutParams(-1,dp(210)).apply{topMargin=dp(6)})
        val choose = TextView(this).apply { text=if(uri==null) "＋ Dodaj jedno zdjęcie" else "Zmień zdjęcie"; textSize=14f; gravity=Gravity.CENTER; setTextColor(Color.rgb(35,58,42)); setPadding(0,dp(8),0,0); setOnClickListener{choosePhoto()} }
        memoryCard.addView(choose)
        memoryCard.addView(TextView(this).apply { text="Małe kroki, wielkie zmiany"; textSize=14f; gravity=Gravity.CENTER; setTextColor(Color.rgb(104,116,90)); typeface=android.graphics.Typeface.create("serif",android.graphics.Typeface.ITALIC); setPadding(0,dp(6),0,0) })
        content.addView(memoryCard, LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})

        val noteCard=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(12));background=card(Color.argb(242,242,235,221),22f)}
        noteCard.addView(TextView(this).apply{text="Notatka dnia";textSize=19f;setTextColor(Color.rgb(45,48,44));typeface=android.graphics.Typeface.DEFAULT_BOLD})
        val note=EditText(this).apply{hint="Co dziś zapamiętać?";setText(prefs.getString("$dateKey-note",""));setTextColor(Color.DKGRAY);setHintTextColor(Color.rgb(130,130,120));minLines=2;gravity=Gravity.TOP;background=card(Color.WHITE,12f);setPadding(dp(12),dp(8),dp(12),dp(8))}
        noteCard.addView(note,LinearLayout.LayoutParams(-1,dp(85)).apply{topMargin=dp(6)})
        noteCard.addView(Button(this).apply{text="ZAPISZ NOTATKĘ";setOnClickListener{prefs.edit().putString("$dateKey-note",note.text.toString()).apply();Toast.makeText(this@MainActivity,"Zapisane ✓",Toast.LENGTH_SHORT).show()}})
        content.addView(noteCard,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})

        updateProgress(checks, selected.size)
    }

    private fun selectedIndices(): List<Int> = (0 until allTasks.size).filter { prefs.getBoolean("tile-$it", true) }.let { if(it.isEmpty()) listOf(0,1,2,3,4,5,6) else it }

    private fun updateProgress(checks: List<CheckBox>, total: Int){ val n=checks.count{it.isChecked}; progress.text=if(n==total) "✓ DZIEŃ ZROBIONY" else "Postęp dnia: $n / $total" }

    private fun choosePhoto(){ val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(intent,photoRequest) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==photoRequest&&resultCode==RESULT_OK){data?.data?.let{uri->try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};prefs.edit().putString("$dateKey-photo",uri.toString()).apply();memoryImage?.setImageURI(uri)}}}

    private fun showMenu(){
        val items=arrayOf("🎨  Wybierz tło","☑  Wybierz kafelki","🗓  Kalendarz miesiąca","ℹ  O Codzienniku")
        AlertDialog.Builder(this).setTitle("Codziennik").setItems(items){_,which->when(which){0->chooseBackground();1->chooseTiles();2->showCalendar();3->showAbout()}}.show()
    }
    private fun chooseBackground(){val names=backgrounds.map{it.first}.toTypedArray();val cur=prefs.getInt("background",0);AlertDialog.Builder(this).setTitle("Wybierz tło").setSingleChoiceItems(names,cur){d,w->prefs.edit().putInt("background",w).apply();d.dismiss();buildUi()}.setNegativeButton("Anuluj",null).show()}
    private fun chooseTiles(){val checked=BooleanArray(allTasks.size){prefs.getBoolean("tile-$it",true)};AlertDialog.Builder(this).setTitle("Kafelki na co dzień").setMultiChoiceItems(allTasks.toTypedArray(),checked){_,which,isChecked->prefs.edit().putBoolean("tile-$which",isChecked).apply()}.setPositiveButton("Zapisz"){_,_->buildUi()}.setNegativeButton("Anuluj",null).show()}
    private fun showCalendar(){val cal=CalendarView(this).apply{date=System.currentTimeMillis()};AlertDialog.Builder(this).setTitle("Kalendarz miesiąca").setView(cal).setPositiveButton("Gotowe",null).show()}
    private fun showAbout(){AlertDialog.Builder(this).setTitle("Codziennik").setMessage("Małe kroki, wielkie zmiany.\n\nTwój prywatny dziennik codziennych rzeczy, które mają znaczenie.").setPositiveButton("OK",null).show()}
}
