CODZIENNIK 2.1

Wersja testowa aplikacji Android.

Zawiera:
- styl Codziennika zgodny z brandbookiem 2.1,
- wybór jednego z 5 teł,
- wybór kafelków na co dzień,
- przekreślanie wykonanych zadań,
- Suplementację i Spacer,
- jedną Pamiątkę z dnia (jedno zdjęcie),
- notatkę dnia,
- menu z kalendarzem miesiąca.
